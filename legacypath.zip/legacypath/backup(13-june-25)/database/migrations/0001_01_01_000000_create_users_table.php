<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('first_name')->nullable();
            $table->string('last_name')->nullable();
            $table->string('email')->nullable();
            $table->string('password')->nullable();
            $table->string('social_id')->nullable();
            $table->string('social_type')->nullable();
            $table->string('profile_img')->nullable();
            $table->string('gender')->nullable();
            $table->string('date_of_birth')->nullable(); 
            $table->string('country')->nullable(); 
            $table->string('country_code')->nullable();
            $table->string('phone_number')->nullable();
            $table->string('type')->nullable();
            $table->string('step')->nullable();
            $table->enum('status',['Suspended','Active',' '])->default('active')->nullable();
            $table->integer('subscriptionStatus')->default(0)->comment('0 = not subscribe, 1 = subscribed');
            $table->string('plan')->nullable();
            $table->string('plan_type')->nullable();
            $table->integer('isCancel')->default(0)->comment('0 = not cancel, 1 = cancel');
            $table->date('firstSubscriptionDate')->nullable();
            $table->integer('is_subscription_mail')->default(0)->comment('0 = not send, 1 = send');
            $table->string('device_token')->nullable();
            $table->string('device_type')->nullable();
            $table->string('is_verified')->default(0)->comment('0 = not verified, 1 = verified')->nullable(); 
            $table->timestamp('email_verified_at')->nullable();
            $table->timestamp('last_activity')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });

        Schema::create('password_reset_tokens', function (Blueprint $table) {
            $table->string('email')->primary();
            $table->string('token');
            $table->timestamp('created_at')->nullable();
        });

        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->foreignId('user_id')->nullable()->index();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->longText('payload');
            $table->integer('last_activity')->index();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
        Schema::dropIfExists('password_reset_tokens');
        Schema::dropIfExists('sessions');
    }
};
