<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class CategoriesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
         Category::create([
            'type' => 'Financial Portfolio',
            'icon' => 'Portfolio.png',
            'type2' => 'Assets',
            'icon2' => 'asset5.png',
            'title' => 'Bank Accounts',
        ]);
        Category::create([
            'type' => 'Financial Portfolio',
            'icon' => 'Portfolio.png',
            'type2' => 'Assets',
            'icon2' => 'asset4.png',
            'title' => 'Real Estate',
        ]);
        Category::create([
            'type' => 'Financial Portfolio',
            'icon' => 'Portfolio.png',
            'type2' => 'Assets',
            'icon2' => 'asset3.png',
            'title' => 'Brokerage Accounts',
        ]);
        Category::create([
            'type' => 'Financial Portfolio',
            'icon' => 'Portfolio.png',
            'type2' => 'Assets',
            'icon2' => 'asset2.png',
            'title' => 'Life Insurance',
        ]);
        Category::create([
            'type' => 'Financial Portfolio',
            'icon' => 'Portfolio.png',
            'type2' => 'Assets',
            'icon2' => 'asset1.png',
            'title' => 'Business Ownerships',
        ]);
         Category::create([
            'type' => 'Financial Portfolio',
            'icon' => 'Portfolio.png',
            'type2' => 'Assets',
            'icon2' => 'asset.png',
            'title' => 'Other (529 Plans, HSA, etc.)',
        ]);
        Category::create([
            'type' => 'Financial Portfolio',
            'icon' => 'Portfolio.png',
            'type2' => 'Debts',
            'icon2' => 'debt2.png',
            'title' => 'Loans',
        ]);
        Category::create([
            'type' => 'Financial Portfolio',
            'icon' => 'Portfolio.png',
            'type2' => 'Debts',
            'icon2' => 'debt1.png',
            'title' => 'Credit Cards',
        ]);
        Category::create([
            'type' => 'Financial Portfolio',
            'icon' => 'Portfolio.png',
            'type2' => 'Debts',
            'icon2' => 'debt.png',
            'title' => 'Other',
        ]);
          Category::create([
            'type' => 'Legal Documents ',
            'icon' => 'document.png',
            'type2' => '',
            'icon2' => 'legal6.png',
            'title' => 'Will',
        ]);
          Category::create([
            'type' => 'Legal Documents ',
            'icon' => 'document.png',
            'type2' => '',
            'icon2' => 'legal5.png',
            'title' => 'Trusts',
        ]);
          Category::create([
            'type' => 'Legal Documents ',
            'icon' => 'document.png',
            'type2' => '',
            'icon2' => 'legal4.png',
            'title' => 'Power of Attorney',
        ]);
          Category::create([
            'type' => 'Legal Documents ',
            'icon' => 'document.png',
            'type2' => '',
            'icon2' => 'legal3.png',
            'title' => 'Real Estate Deeds',
        ]);
          Category::create([
            'type' => 'Legal Documents ',
            'icon' => 'document.png',
            'type2' => '',
            'icon2' => 'legal2.png',
            'title' => ' Business Documents',
        ]);
          Category::create([
            'type' => 'Legal Documents ',
            'icon' => 'document.png',
            'type2' => '',
            'icon2' => 'legal1.png',
            'title' => 'Tax Returns',
        ]);
        Category::create([
            'type' => 'Legal Documents ',
            'icon' => 'document.png',
            'type2' => '',
            'icon2' => 'legal.png',
            'title' => 'Other',
        ]);
          Category::create([
            'type' => 'Logins',
            'icon' => 'logins.png',
            'type2' => '',
            'icon2' => 'login.png',
            'title' => '',
        ]);
          Category::create([
            'type' => 'Life Journals',
            'icon' => 'journals.png',
            'type2' => '',
            'icon2' => 'journal.png',
            'title' => '',
        ]);
    }
}
