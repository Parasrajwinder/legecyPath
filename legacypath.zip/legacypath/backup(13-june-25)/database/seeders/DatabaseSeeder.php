<?php

namespace Database\Seeders;

use App\Models\Admin;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\Category;

class DatabaseSeeder extends Seeder
{
        protected $model = Admin::class;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        if ( Category::first() === null ) {
            // If the table is empty, call the CategoriesTableSeeder
            $this->call(CategoriesTableSeeder::class);
        }
        if( Admin::first() === null ){
        
            Admin::factory()->create([
                'name' => 'admin',
                'email' => 'admin@legecypath.com',
                'password'=>Hash::make('admin@legecypath@123'),
                'created_at' => now(),
                'updated_at' => now(),
            ]);    
        }
        
    }
}
