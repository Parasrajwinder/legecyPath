<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\admin\AuthController;
use App\Http\Middleware\Authenticate;
use App\Http\Controllers\admin\AdminController;

// Route::get('showLogin', [AuthController::class, 'showLogin'])->name('showLogin');
Route::get('login',[AuthController::class,'login'])->name('login');
Route::post('login',[AuthController::class,'postLogin'])->name('post.login');
Route::get('showForgotPassword',[AuthController::class,'showForgotPassword'])->name('showForgotPassword');
Route::post('sendResetOtp',[AuthController::class,'sendResetOtp'])->name('sendResetOtp');
Route::post('verifyOtp',[AuthController::class,'verifyOtp'])->name('verifyOtp');
Route::get('otp',[AuthController::class,'otp'])->name('otp');
Route::get('showChangePassword',[AuthController::class,'showChangePassword'])->name('showChangePassword');
Route::post('/password/update', [AuthController::class, 'updatePassword'])->name('password.update');
Route::get('showResetPassword',[AuthController::class, 'showResetPassword'])->name('showResetPassword');
Route::post('/reset-password', [AuthController::class, 'resetPassword'])->name('resetPassword');
Route::get('/resend-otp', [AuthController::class, 'resendOtp'])->name('resendOtp');


   
Route::prefix('admin')->middleware('authenticate')->group(function () {
    
Route::get('/dashboard',[AuthController::class,'dashboard'])->name('dashboard');
Route::get('logout',[AuthController::class,'logout'])->name('logout');
Route::get('getUsers',[AdminController::class, 'getUsers'])->name('getUsers');
Route::get('/users/{id}',[AdminController::class,'show'])->name('users.details');
Route::post('/users/suspend', [AdminController::class, 'suspend'])->name('users.suspend');
Route::get('/user/{id}', [AdminController::class, 'destroy'])->name('users.destroy');
Route::get('profile', [AdminController::class, 'edit'])->name('profile');
Route::post('profile/update', [AdminController::class, 'updateProfile'])->name('profile.update');
Route::get('show/Quotes',[AdminController::class,'showQuotes'])->name('showQuotes');
Route::post('/quotes', [AdminController::class, 'addQuote'])->name('addQuote');
Route::post('/quotes/update', [AdminController::class, 'updateQuote'])->name('updateQuote');
Route::delete('/quotes/{id}', [AdminController::class, 'destroyQuote'])->name('destroyQuote');
Route::get('showReport',[AdminController::class,'showReport'])->name('showReport');
Route::post('/reply-user', [AdminController::class, 'replyuser'])->name('reply.user');

    
});


Route::get('/', function () {
    return view('welcome');
});

Route::get('/term', function () {
    return view('page.terms');
});
Route::get('/privacy-policy', function () {
    return view('page.privacy-policy');
});
