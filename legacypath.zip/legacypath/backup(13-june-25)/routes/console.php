<?php
  
use Illuminate\Support\Facades\Schedule;
use App\Console\Commands\DeleteOldLogs;
  
Schedule::command('logs:delete-old')->everyMinute();