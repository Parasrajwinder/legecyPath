<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class SuspendUser
{ 
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle( Request $request, Closure $next ): Response
    { 
        // If the user account is suspended
        if ( Auth::check() && Auth::user()->status=="Active" ) {
            return $next($request);
        }else{
            return response()->json([ 
                'success' => false,
                'status'  => 403,
                'message' => 'Your account has been suspended by the admin.',
            ], 403 );
        }
    }
}
