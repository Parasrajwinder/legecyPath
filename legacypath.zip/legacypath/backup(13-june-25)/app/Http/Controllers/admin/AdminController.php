<?php

namespace App\Http\Controllers\admin;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use App\Models\Admin; 
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Quote;
use App\Models\ContactUs;
use App\Models\Subscription;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;



class AdminController extends Controller
{

    
    public function edit() {
        $admin = Auth::guard('admin')->user(); 
        return view('admin.profile', compact('admin'));
    }
 
    public function updateProfile(Request $request) {
        $admin = Auth::guard('admin')->user(); 

        $request->validate([
            'firstname' => 'required|string|max:255',
            'lastname' => 'required|string|max:255',
            'photo' => 'nullable|image|mimes:jpg,png,jpeg',
        ]);
    
        if ($request->hasFile('photo')) {
            if (!empty($admin->photo)) {
                $existingPhotoPath = 'admin/' . $admin->photo;
        
                if (Storage::disk('public')->exists($existingPhotoPath)) {
                  Storage::disk('public')->delete($existingPhotoPath);
                }
            }
        
            $fileName = time() . '_' . $request->file('photo')->getClientOriginalName();
            $filePath = $request->file('photo')->storeAs('admin', $fileName, 'public');
        
            $admin->photo = $fileName;
        
            $admin->save();
        }
            $admin->firstname = $request->firstname;
            $admin->lastname = $request->lastname;
            $admin->save();
    
            return redirect()->route('profile')->with('success', 'Profile updated successfully');
    }
    
    public function getUsers() {
        
    $users = User::orderBy('created_at', 'desc')->get();
        
    return view('admin.users',compact('users'));
    }
    
    public function show($id) {
        $user = User::where('id',$id)->first();
        return view('admin.user-detail', compact('user'));
    }

    public function suspend(Request $request) {
        $id = $request->id;
        $type = $request->status;
        
        $user = User::where('id',$id)->first();
        $user->status = $type;
        $user->save();
    
        return response()->json(['success' => 'User suspended successfully!']);
    }

    public function destroy($id) {
        $user = User::find($id);
        if (!$user) {
            return response()->json(['error' => 'User not found'], 404);
        }
    
        $user->delete();
    
        return response()->json(['success' => 'User deleted successfully']);
    }
    
    public function showQuotes() {
        $quotes = Quote::latest()->get();;
        return view('admin.quotes', compact('quotes'));
    }
    
public function addQuote(Request $request) {
    $request->validate([
        'quotes' => ['required', function ($attribute, $value, $fail) {
            if (trim($value) === '') {
                $fail("The $attribute field cannot be empty or contain only spaces.");
            }
        }],
        'author' => ['required', function ($attribute, $value, $fail) {
            if (trim($value) === '') {
                $fail("The $attribute field cannot be empty or contain only spaces.");
            }
        }],
    ]);

    $quote = Quote::create([
        'quotes' => $request->quotes,
        'author' => $request->author,
    ]);

    return redirect()->route('showQuotes')->with('success', 'Quote added successfully.');
}


    public function updateQuote(Request $request) {
        $request->validate([
            'quotes' => 'required',
            'author' => 'required',
        ]);

        $quote = Quote::findOrFail($request->id);
        $quote->update([
            'quotes' => $request->quotes,
            'author' => $request->author,
        ]);

        return response()->json(['success' => 'Quote updated successfully!', 'data' => $quote]);
    }

    public function destroyQuote($id) {
        Quote::findOrFail($id)->delete();
        return response()->json(['success' => 'Quote deleted successfully!']);
    }
    
    public function showReport() {
        
        $reports = ContactUs::get();
        
        return view('admin.report-management',compact('reports'));
    }
    
 public function replyuser(Request $request)
    {
        $validatedData = $request->validate([
            'userid' => 'required',
            'replymssagee' => 'required',
        ]);
        
        $id = $validatedData['userid'];
        $message = $validatedData['replymssagee'];

       
        $issue = ContactUs::where('id', $id)->first();
        if (!$issue) {
            return redirect()->route('issue.index')->with('error', 'Issue not found');
        }
        
        // $useremail = "phpdeveloper@parastechnologies.com";
        $useremail = $issue->email;
        $subject = $issue->subject . ' - Reply';

       $mail =  parent::sendreply($subject, $message, $useremail);
       if($mail['success'] == 1){
            return response()->json([
                'message'=>'Replied successfully!'
                ]);
       }else{
            return redirect()->route('showReport')->with('error', $mail['message']); 
       }
    }
    
}
