<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Mail\forgotPassword;
use Illuminate\Support\Facades\DB;
use App\Models\Admin;
use App\Models\Subscription;
use App\Models\User;
use Carbon\Carbon;




class AuthController extends Controller
{
    
 public function login(){
    return view('admin.auth.login');
}

  public function dashboard()
{
    $activeUsersCount = User::where('status', 'active')->count();
    $totalUsersCount = User::count();
    $totalRevenue = DB::table('subscriptions')
    ->selectRaw("SUM(CAST(REPLACE(amount, '$', '') AS DECIMAL(10,2))) as total")
    ->value('total');


    $currentYear = Carbon::now()->year;
    $years = [];
    $revenueByYear = [];
    $activeUsersByYear = [];

    for ($i = 3; $i >= 0; $i--) {
        $year = $currentYear - $i;
        $years[] = $year;

        $revenue = Subscription::whereYear('created_at', $year)->selectRaw("SUM(CAST(REPLACE(amount,'$','') AS DECIMAL (10,2))) as total")->value('total');
        $activeUsers = User::where('status', 'active')->whereYear('created_at', $year)->count();

        $revenueByYear[$year] = (int) $revenue;
        $activeUsersByYear[$year] = $activeUsers;
    }

    return view('admin.dashboard', compact(
        'activeUsersCount',
        'totalUsersCount',
        'totalRevenue',
        'revenueByYear',
        'activeUsersByYear'
    ));
}



 public function postLogin(Request $request)
{
    $request->validate([
        'email' => 'required|email',
        'password' => 'required',
    ]);

    $remember = $request->has('remember');

    $user = \App\Models\Admin::where('email', $request->email)->first();

    if (!$user) {
        return back()->withErrors(['email' => 'Incorrect email.']);
    }

    if (!Auth::guard('admin')->attempt(['email' => $request->email, 'password' => $request->password], $remember)) {
        return back()->withErrors(['password' => 'Incorrect password.']);
    }

    return redirect()->route('dashboard');
}
    
    public function showForgotPassword(){
        return view('admin.auth.Forgotpassword');
    }
    
    public function otp(){
        return view('admin.auth.otp-verification');
    }
    
public function sendResetOtp(Request $request)
{
    $request->validate([
        'email' => 'required|email|exists:admins,email',
    ]);

    try {
        $admin = Admin::where('email', $request->email)->first();

        if (!$admin) {
            return redirect()->back()->with('error', 'Admin not found.');
        }

        // Generate OTP
        $otp = rand(1000, 9999);

        // Store OTP in password_reset_tokens table
        DB::table('password_reset_tokens')->updateOrInsert(
            ['email' => $admin->email],
            ['token' => $otp, 'created_at' => now()]
        );

        // Mail Data
        $mailData = [
            'title' => 'Forgot Password Request',
            'body' => 'You have requested to reset your password. Please use the following OTP to proceed.',
            'token' => $otp,
            'name' => $admin->first_name. ' ' .$admin->last_name
        ];

        // Send OTP via Email
        Mail::to($admin->email)->send(new ForgotPassword($mailData));

        session(['reset_email' => encrypt($admin->email)]);

        return redirect()->route('otp')->with([
            'success' => 'An OTP has been sent to your email.',
            'email' => $admin->email
        ]);
    } catch (\Exception $e) {
        \Log::error('OTP Send Error: ' . $e->getMessage());
        return redirect()->back()->with('error', 'Something went wrong. Please try again.');
    }
}

public function verifyOtp(Request $request)
{
    $request->validate([
        'token' => 'required|array', 
        'token.*' => 'required|digits:1',
    ]);

    $email = session('reset_email') ? decrypt(session('reset_email')) : null;

    if (!$email) {
        return redirect()->route('showForgotPassword')->with('error', 'Session expired. Please request a new OTP.');
    }

    $otp = implode('', $request->token);

    $record = DB::table('password_reset_tokens')->where('email', $email)->first();

    if (!$record) {
        return redirect()->back()->with('error', 'Invalid OTP or email.');
    }

    if ($record->token == $otp) {
        DB::table('password_reset_tokens')->where('email', $email)->delete();

        return redirect()->route('showResetPassword')->with('success', 'OTP verified successfully.');
    } else {
        return redirect()->back()->with('error', 'Invalid OTP.');
    }
}

    public function resendOtp(Request $request) {
        $email = session('reset_email') ? decrypt(session('reset_email')) : null;
    
        if (!$email) {
            return redirect()->route('showForgotPassword')->with('error', 'Session expired. Please request a new OTP.');
        }
    
        try {
            $admin = Admin::where('email', $email)->first();
            if (!$admin) {
                return redirect()->back()->with('error', 'Admin not found.');
            }
    
            $otp = rand(1000, 9999);
    
            DB::table('password_reset_tokens')->updateOrInsert(
                ['email' => $admin->email],
                ['token' => $otp, 'created_at' => now()]
            );
    
            $mailData = [
                'title' => 'Resend OTP Request',
                'body' => 'Here is your new OTP for password reset.',
                'token' => $otp,
                'name' => $admin->first_name. ' ' .$admin->last_name
            ];
    
            Mail::to($admin->email)->send(new ForgotPassword($mailData));
    
            return redirect()->back()->with('success', 'A new OTP has been sent to your email.');
        } catch (\Exception $e) {
            \Log::error('Resend OTP Error: ' . $e->getMessage());
            return redirect()->back()->with('error', 'Something went wrong. Please try again.');
        }
    }

    public function resetPassword(Request $request) {
        $request->validate([
            'password' => 'required|min:8|confirmed',
        ]);

        $email = session('reset_email') ? decrypt(session('reset_email')) : null;

        if (!$email) {
            return redirect()->route('showForgotPassword')->with('error', 'Session expired. Please request a new OTP.');
        }

        $admin = Admin::where('email', $email)->first();

        if (!$admin) {
            return redirect()->route('showForgotPassword')->with('error', 'Admin not found.');
        }

        $admin->update([
            'password' => Hash::make($request->password),
        ]);

        session()->forget('reset_email');

        return redirect()->route('login')->with('success', 'Your password has been reset successfully. You can now login.');
    }


    
    public function showChangePassword(){
        return view('admin.auth.change-password');
    }
    
    public function updatePassword(Request $request)
    {
        $request->validate([
            'password' => 'required',
            'new_password' => 'required',
            'confirm_password' => 'required|same:new_password',
        ]);

         $user=Auth::guard('admin')->user();

        if (!Hash::check($request->password, $user->password)) {
            return back()->withErrors(['password' => 'Old password is incorrect']);
        }

        $user->password = Hash::make($request->new_password);
        $user->save();

        return back()->with('success', 'Password updated successfully');
    }
    
    public function showResetPassword(){
        return view('admin.auth.Reset-Password');
    }
    
    
     public function logout(Request $request)
    {
        auth()->logout(); 
        $request->session()->invalidate(); 
        $request->session()->regenerateToken(); 

        return redirect()->route('login'); 
    }
    
  

}
