<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\File;
use Carbon\Carbon;

class DeleteOldLogs extends Command
{
    // The name and signature of the console command
    protected $signature = 'logs:delete-old';

    // The console command description
    protected $description = 'Delete log files older than 7 days';

    // Create a new command instance
    public function __construct()
    {
        parent::__construct();
    }

    // Execute the console command
public function handle()
{
    $logPath = storage_path('logs'); // Path to the logs folder
    $daysOld = 7; // Number of days logs should be older than to be deleted

    // Get all the files in the logs folder
    $files = File::allFiles($logPath);
    $deletedFiles = 0;

    // Debugging output: Show current date
    $this->info("Current date and time: " . Carbon::now()->toDateTimeString());

    // Loop through each file and check if it's older than 7 days
    foreach ($files as $file) {
        $lastModified = Carbon::createFromTimestamp($file->getMTime()); // Get last modified time

        // Debugging output: Display last modified time of each file
        $this->info("Checking file: {$file->getFilename()} Last modified: " . $lastModified->toDateTimeString());

        // If file is older than 7 days, delete it
        if ($lastModified->isBefore(Carbon::now()->subDays($daysOld))) {
            File::delete($file);
            $deletedFiles++;
            $this->info("Deleted: {$file->getFilename()}");
        } else {
            $this->info("Skipping file: {$file->getFilename()} (Not older than 7 days)");
        }
    }

    // Output the number of deleted files
    $this->info("Deleted {$deletedFiles} log files older than {$daysOld} days.");
}


}
