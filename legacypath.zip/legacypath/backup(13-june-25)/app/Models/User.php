<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'first_name',
        'last_name',
        'email',
        'password',
        'otp',
        'social_id',
        'social_type',
        'is_verified',
        'email_verified_at',
        'profile_img',
        'gender',
        'date_of_birth',
        'country',
        'country_code',
        'phone_number',
        'type',
        'step',
        'status',
        'subscriptionStatus',
        'plan',
        'plan_type',
        'isCancel',
        'firstSubscriptionDate',
        'is_subscription_mail',
        'device_token',
        'device_type',
        'last_activity'
        
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
        'otp'
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed'
        ];
    }
    
    public function maxStorageLimit() {
        if($this->subscriptionStatus==1 && ($this->plan=="premiun_plan_monthly" || $this->plan=="premiun_plan_yearly")){
            return 100 * 1024 * 1024;
        }
        if($this->subscriptionStatus==1 && ($this->plan=="basic_plan_monthly" || $this->plan=="basic_plan_yearly")){
            return 50 * 1024 * 1024;
        }
        else{
            return 0;
        }
    }
    
    public function bankaccount() {
        return $this->hasMany( BankAccount::class, 'user_id' );
    }
     public function realasset() {
        return $this->hasMany( RealEstate::class, 'user_id' );
    }
     public function brokerageaccount() {
        return $this->hasMany( BrokerageAccount::class, 'user_id' );
    }
     public function lifeinsurance() {
        return $this->hasMany( LifeInsurance::class, 'user_id' );
    }
     public function businessownership() {
        return $this->hasMany( BusinessOwnership::class, 'user_id' );
    } 
    public function loan() {
        return $this->hasMany( Loan::class, 'user_id' );
    }
     public function creditcard() {
        return $this->hasMany( CreditCard::class, 'user_id' );
    }
     public function otherasset() {
        return $this->hasMany( OtherAsset::class, 'user_id' );
    }
     public function otherdebt() {
        return $this->hasMany( OtherDebt::class, 'user_id' );
    }
    public function lifejournals() {
        return $this->hasMany( LifeJournal::class, 'user_id' );
    }
    public function subscription() {
        return $this->hasOne(Subscription::class, 'user_id'); // Assuming 'user_id' is the foreign key
    }
}
