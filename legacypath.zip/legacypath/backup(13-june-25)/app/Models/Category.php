<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Category extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    
        protected $table = 'categories';
  
        protected $primaryKey = 'id';
    
    protected $fillable = [
        'type',
        'icon',
        'type2',
        'icon2',
        'title',
        'status',
    ];

    
    public function bankaccount() {
        return $this->hasMany( BankAccount::class, 'category_id' );
    }
     public function realasset() {
        return $this->hasMany( RealEstate::class, 'category_id' );
    }
     public function brokerageaccount() {
        return $this->hasMany( BrokerageAccount::class, 'category_id' );
    }
     public function lifeinsurance() {
        return $this->hasMany( LifeInsurance::class, 'category_id' );
    }
     public function businessownership() {
        return $this->hasMany( BusinessOwnership::class, 'category_id' );
    }
    public function otherasset() {
        return $this->hasMany( OtherAsset::class, 'category_id' );
    }
    public function loan() {
        return $this->hasMany( Loan::class, 'category_id' );
    }
    public function creditcard() {
        return $this->hasMany( CreditCard::class, 'category_id' );
    }
    public function otherdebt() {
        return $this->hasMany( OtherDebt::class, 'category_id' );
    }
    
    public function legalwill() {
        return $this->hasMany( LegalWill::class, 'category_id' );
    }
    public function legaltrust() {
        return $this->hasMany( LegalTrust::class, 'category_id' );
    }
    public function powerattorney() {
        return $this->hasMany( PowerAttorney::class, 'category_id' );
    }
    public function realestatedeed() {
        return $this->hasMany( RealEstateDeed::class, 'category_id' );
    }
    public function businessdocument() {
        return $this->hasMany( BusinessDocument::class, 'category_id' );
    }
    public function taxreturndocument() {
        return $this->hasMany( TaxReturnDocument::class, 'category_id' );
    }
    public function otherlegaldocument() {
        return $this->hasMany( OtherLegalDocument::class, 'category_id' );
    }
    
    public function logins() {
        return $this->hasMany( Login::class, 'category_id' );
    }
    
    public function lifejournals() {
        return $this->hasMany( LifeJournal::class, 'category_id' );
    }
    
    
}
