<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class SendCustomMail extends Mailable
{
    use Queueable, SerializesModels;

    public $emailSubject;
    public $body;


    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($subject, $body)
    {
        $this->emailSubject  = $subject;
        $this->body = $body;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
         return $this->view('emails.custom')
                    ->with([
                        'subject' => $this->emailSubject, // Pass subject to the view
                        'body' => $this->body,
                    ])
                    ->subject($this->emailSubject); // Set email subject
    }
}
