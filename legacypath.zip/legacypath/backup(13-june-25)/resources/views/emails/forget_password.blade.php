<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&display=swap" rel="stylesheet">
    <title>Legacypath Email Template</title>
</head>

<body style="font-family: 'DM Sans', sans-serif; border: 0; margin: 0; padding: 0;">
    <div class="order-block" style="width: 600px; margin: 0 auto 0px; font-weight: 400;">
        <div class="full-block order-delivery" style="width: 100%; float: left; border-radius:10px;
            box-shadow: 0px 1px 5px 1px #d8d5d5; border: 1px solid #fff; padding: 0; background: #fff; margin: 5px 0; overflow: hidden;">
            <div class="log_img" style="text-align: center;padding: 30px 0; background:#E4DED5;
            background-repeat: no-repeat;background-size: cover;">
                <img src="{{asset('public/Assets/images/logo.png')}}" style="width: 185px;">
            </div>
            <div class="pass-block" style="text-align: center; padding: 30px 0 0px 0;">
            </div>
            <div class="email-block-full" style="padding: 0 11px; margin-top: 5px;">
                <h1 style="text-align:left; color: #000; margin: 0 0 10px 0; padding-left:10px; font-weight: 400; font-size:16px; padding-bottom: 10px;">
                <strong></strong></h1>
                <h3 style="text-align: left; padding: 0px 12px 10px 10px; margin: 0px; font-size:19px; font-weight: 400;">
                    Dear<span style="margin-left: 10px;"><strong>{{ $mailData['name'] }}</strong></span>
                </h3>
                <!-- <p><strong>Email:</strong> <a href="javascript:;">deekersmaeker.nils@gmail.com</a></p> -->
                <p style="text-align: left; padding: 0 18px 0 12px; font-size: 15px; line-height:28px; color: #000; margin-top: 0px; margin-bottom: 0;">
                    Thank you for signing up with Legacypath. To complete your verification process, please use otp.
                </p>
                <p style="margin-top: left; padding: 16px 18px 16px 12px; font-size: 15px; line-height: 31px; color: #000; margin-top: 0px; margin-bottom:0px;">
                    <p style="margin-left: 10px;">Your OTP is: <strong>{{ $mailData['token'] }}</strong></p>
                    <p style="text-align: left; padding: 0px 18px 12px 12px; font-size: 15px; line-height:28px; color: #000; margin-top: 0px; margin-bottom: 8px;">
                        Please do not share it with anyone for security reasons.</p>
                    <p style="text-align: left;
                    padding: 0 18px 0 12px;
                    font-size: 15px;
                    line-height:24px;
                    color: #000;
                    margin-top: 0px;
                    margin-bottom: 0px;"><strong>Best regards</strong> </p>
                    <p style="text-align: left;
                    padding: 0 18px 0 12px;
                    font-size: 15px;
                    line-height:25px;
                    color: #000;
                    margin-top: 0px;
                    margin-bottom: 8px;">LegacyPath Team.</p>
                    </div>
                      <div class="copyright" style="
                        float: left;
                        width: 97.8%;
                        text-align: center;
                        background: linear-gradient(90deg, rgba(197,141,109,1) 0%, rgba(184,183,163,1) 64%);
                        color: #fff;
                        padding: 16px 8px;
                        font-size: 13px;
                        margin-top:18px;
                        font-weight: 600;
                        ">Copyrights © Legacypath Ltd. All Rights Reserved</div>
                            </div>
                        </div>
                        </div>
</body>
</html>