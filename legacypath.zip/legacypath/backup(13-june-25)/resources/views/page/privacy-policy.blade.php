<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms and Conditions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }

        header {
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
        }

        h1, h2, h3 {
            color: #333;
        }

        p {
            margin: 10px 0;
        }

        ul {
            list-style-type: disc;
            padding-left: 40px;
        }

        footer {
            text-align: center;
            padding: 20px 0;
            background-color: #f2f2f2;
            color: #777;
            margin-top: 40px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Privacy Policy</h1>
    </header>
    <div class="container">
       <p>Welcome to LegacyPath App. Your privacy is important to us. This Privacy Policy explains how we collect, use, and protect your information when you use our mobile application.</p>

<h2>1. Information We Collect</h2>
<p>We may collect personal information that you provide to us, such as your name, email address, and device information. We also collect usage data to improve our services.</p>

<h2>2. How We Use Your Information</h2>
<p>Your information is used to:</p>
<ul>
  <li>Provide and maintain our services</li>
  <li>Communicate with you, including sending OTPs or notifications</li>
  <li>Improve the app functionality and user experience</li>
  <li>Ensure security and prevent fraud</li>
</ul>

<h2>3. Data Sharing and Disclosure</h2>
<p>We do not sell or rent your personal data. We may share your information with trusted third-party service providers who help us operate the app, but only to the extent necessary.</p>

<h2>4. Data Security</h2>
<p>We implement appropriate technical and organizational measures to protect your data against unauthorized access, alteration, disclosure, or destruction.</p>

<h2>5. Your Choices</h2>
<p>You may update or delete your personal information by contacting our support team. You can also opt out of receiving marketing communications.</p>

<h2>6. Children’s Privacy</h2>
<p>Our app is not intended for children under 13. We do not knowingly collect personal information from children under 13.</p>

<h2>7. Changes to This Privacy Policy</h2>
<p>We may update this Privacy Policy from time to time. We encourage you to review this page periodically for any changes.</p>

<h2>8. Contact Us</h2>
<p>If you have questions or concerns about this Privacy Policy, please contact us at <a href="mailto:privacy@legacypathapp.com">privacy@legacypathapp.com</a>.</p>
    </div>
    <footer>
        <p>&copy; 2025 LegacyPath LLC. All rights reserved.</p>
    </footer>
</body>
</html>
