<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms and Conditions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }

        header {
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
        }

        h1, h2, h3 {
            color: #333;
        }

        p {
            margin: 10px 0;
        }

        ul {
            list-style-type: disc;
            padding-left: 40px;
        }

        footer {
            text-align: center;
            padding: 20px 0;
            background-color: #f2f2f2;
            color: #777;
            margin-top: 40px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Terms and Conditions</h1>
    </header>
    <div class="container">
        <p>Welcome to the LegacyPath app (“App”). These Terms and Conditions (“Terms”) govern your use of the App, which is owned and operated by LegacyPath LLC (“we”, “us”, or “our”). By using the App, you agree to comply with these Terms.</p>

        <h3>1. Eligibility</h3>
        <p>You must be at least 16 years old to use this App. By accessing or using the App, you confirm that you meet this age requirement and agree to abide by these Terms.</p>

        <h3>2. User Accounts</h3>
        <ul>
            <li> You may be required to create an account to access certain features.</li>
            <li>You are responsible for maintaining the confidentiality of your login credentials and for all activity under your account.</li>
            <li> You agree to provide accurate, current, and complete information during registration and to update it as necessary.</li>
        </ul>

        <h3>3. App Content and Usage</h3>
        <ul>
            <li>All content, features, and functionality in the App are the intellectual property of LegacyPath LLC or its licensors.</li>
            <li>You may not copy, reproduce, distribute, or create derivative works from the App or its content without prior written consent.</li>
        </ul>

        <h3>4. User-Generated Content</h3>
        <ul>
            <li>You retain ownership of the content you post, but grant LegacyPath LLC a non-exclusive, royalty-free, worldwide license to use, display, and distribute that content for purposes related to the App.</li>
            <li>You agree not to post content that is offensive, unlawful, harassing, or infringes on the rights of others.</li>
        </ul>

        <h3>5. Prohibited Conduct</h3>
        <p>You may not:</p>
        <ul>
            <li>Use the App in any unlawful or harmful way</li>
            <li>Attempt to gain unauthorized access to systems or data</li>
            <li>Disrupt the normal operation or security of the App</li>
            <li> Upload malware, viruses, or malicious content</li>
        </ul>

        <h3>6. Termination</h3>
        <p>We reserve the right to suspend or terminate your access to the App at any time, with or without notice, for any violation of these Terms.</p>

        <h3>7. Disclaimer and Limitation of Liability</h3>
        <ul>
            <li>The App is provided “as is” without warranties of any kind.</li>
            <li>LegacyPath LLC is not liable for any indirect, incidental, or consequential damages resulting from your use of the App.</li>
        </ul>

        <h3>8. Changes to These Terms</h3>
        <p>We may modify these Terms at any time. Continued use of the App after updates means you accept the revised Terms.</p>

        <hr>

        <h2>Privacy Policy</h2>
        <p>This Privacy Policy outlines how LegacyPath LLC (“we”, “us”, or “our”) collects, uses, and protects your personal information when you use the LegacyPath app (“App”).</p>

        <h3>1. Information We Collect</h3>
        <ul>
            <li><strong>Personal Information:</strong> Name, email, profile details, and content you submit.</li>
            <li><strong>Technical Information:</strong> Device ID, IP address, browser type, usage data, and logs.</li>
        </ul>

        <h3>2. How We Use Your Information</h3>
        <p>We use your data to:</p>
        <ul>
            <li>Provide and improve App functionality</li>
            <li>Customize your experience</li>
            <li>Respond to support requests</li>
            <li>Communicate with you regarding your account or app updates</li>
            <li>Comply with legal and regulatory obligations</li>
        </ul>

        <h3>3. Sharing Your Information</h3>
        <p>We do not sell your personal data. We may share your information only with:</p>
        <ul>
            <li>Trusted third-party service providers assisting in App operations</li>
            <li>Legal authorities, if required by law or to protect the safety of users or the public</li>
        </ul>
         <h3>4. Data Security</h3>
        <p>We take the security of your data seriously. Measures include:</p>
        <ul>
            <li>Encrypted data transmission using HTTPS</li>
            <li>Secure storage with access restricted to authorized personnel</li>
            <li>Regular monitoring for unauthorized access and vulnerabilities</li>
            <li>Prompt response to potential security incidents</li>
        </ul>
        <p>While we follow industry best practices to safeguard your data, no method of transmission or storage is 100% secure. You use the App at your own risk and are encouraged to use strong, unique passwords.</p>
        <h3>5. Your Rights and Choices</h3>
        <p>You may:</p>
        <ul>
            <li>Access or update your account information</li>
            <li>Request deletion of your account or data by contacting us</li>
            <li> Opt out of non-essential communications</li>
        </ul>

        <h3>6. Children’s Privacy</h3>
        <p>The App is not intended for children under 16 years of age. We do not knowingly collect information from individuals under 16. If we become aware of such data, we will delete it promptly.</p>

        <h3>7. Changes to This Policy</h3>
        <p>We may update this Privacy Policy periodically. Significant changes will be communicated through the App or via email.</p>
        <hr>
        <h3>Contact Us</h3>
        <p>If you have questions or concerns about these Terms or this Privacy Policy, please contact us at:</p>
        <p><strong>Email:</strong> admin@legacypathapp.com</p>
        <p><strong>Business Name:</strong> LegacyPath LLC</p>
    </div>
    <footer>
        <p>&copy; 2025 LegacyPath LLC. All rights reserved.</p>
    </footer>
</body>
</html>
