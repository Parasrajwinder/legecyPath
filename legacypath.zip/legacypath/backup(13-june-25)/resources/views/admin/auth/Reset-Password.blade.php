<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>LegacyPath - Reset Password</title>
    <link rel="icon" type="image/x-icon" href="{{ asset('public/Assets/images/favicon.png') }}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('public/Assets/css/style.css') }}">
  </head>
  <body>
    
    <div class="login_box h-100 d-flex align-items-center">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-sm-5">
            <div class="login_form">
              <div class="text-center">
                <img src="{{ asset('public/Assets/images/Logo.svg') }}" alt="Logo" class="mb-4">
                <h1>Reset Password</h1>
                <p class="mb-4">Create a new password and confirm it to continue.</p>
              </div>

              <!-- Success & Error Messages -->
              @if (session('success'))
                <div class="alert alert-success">{{ session('success') }}</div>
              @endif
              @if (session('error'))
                <div class="alert alert-danger">{{ session('error') }}</div>
              @endif
              @if ($errors->any())
                <div class="alert alert-danger">
                  <ul class="mb-0">
                    @foreach ($errors->all() as $error)
                      <li>{{ $error }}</li>
                    @endforeach
                  </ul>
                </div>
              @endif

              <form action="{{ route('resetPassword') }}" method="POST">
                @csrf
                <div class="mb-3 position-relative">
                    <label for="password" class="form-label text_black fw-500 font-14">New Password</label>
                    <input type="password" class="form-control" name="password" id="password" placeholder="Enter new password" required>
                    <span class="eye-icon">
                      <img src="{{ asset('public/Assets/images/eye-open.svg') }}" alt="Show Password">
                    </span>
                </div>

                <div class="mb-4 position-relative">
                    <label for="password_confirmation" class="form-label text_black fw-500 font-14">Confirm Password</label>
                    <input type="password" class="form-control" name="password_confirmation" id="password_confirmation" placeholder="Confirm password" required>
                    <span class="eye-icon">
                      <img src="{{ asset('public/Assets/images/eye-open.svg') }}" alt="Show Password">
                    </span>
                </div>

                <button type="submit" class="btn btn-primary main-gradient w-100">Submit</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
