<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>LegacyPath</title>
    <link rel="icon" type="image/x-icon" href="{{asset('public/Assets/images/favicon.png')}}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('public/Assets/css/style.css')}}">
  </head>
  <body>
    
    <div class="login_box h-100 d-flex align-items-center">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-sm-5">
            <div class="login_form">
              <div class="text-center">
                <img src="{{asset('public/Assets/images/Logo.svg')}}" alt="" class="mb-4">

              <h1>Forgot password?</h1>
              <p class="mb-3">Don't worry! Please enter the email address linked with your account.</p>
              </div>
                                  @if (session('success'))
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                    @endif
                    
                    @if (session('error'))
                        <div class="alert alert-danger">
                            {{ session('error') }}
                        </div>
                    @endif
              
              <form action="{{ route('sendResetOtp') }}" method="POST">
                @csrf
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label text_black fw-500 font-14">Email</label>
                    <input type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email address" required>
                        @if ($errors->has('email'))
                        <span class="error text-danger">
                            <i>{{ $errors->first('email') }}</i>
                        </span>
                    @endif
                </div>
                <button type="submit" class="btn btn-primary main-gradient w-100">Submit</button>
            </form>

            </div>
      
          </div>
          
        </div>
      </div>
      
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>