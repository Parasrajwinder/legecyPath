<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>LegacyPath - Verify OTP</title>
    <link rel="icon" type="image/x-icon" href="{{ asset('public/Assets/images/favicon.png') }}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('public/Assets/css/style.css') }}">
</head>
<body>

<div class="login_box h-100 d-flex align-items-center">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-sm-5">
                <div class="login_form">
                    <div class="text-center">
                        <h1>Forgot Password?</h1>
                        <p class="mb-4">Enter the OTP sent to your email.</p>
                    </div>

                    <!-- Success & Error Messages -->
                    @if (session('success'))
                        <div class="alert alert-success">{{ session('success') }}</div>
                    @endif
                    
                    @if (session('error'))
                        <div class="alert alert-danger">{{ session('error') }}</div>
                    @endif

                    <form method="POST" action="{{ route('verifyOtp') }}">
                        @csrf
                        <input type="hidden" name="email" value="{{ session('email') }}">

                        <div class="otp_verify_box mb-3 d-flex gap-2 justify-content-center">
                            <input type="text" class="form-control text-center otp-field" name="token[]" maxlength="1" required>
                            <input type="text" class="form-control text-center otp-field" name="token[]" maxlength="1" required>
                            <input type="text" class="form-control text-center otp-field" name="token[]" maxlength="1" required>
                            <input type="text" class="form-control text-center otp-field" name="token[]" maxlength="1" required>
                        </div>

                        <p class="text-center mb-4">
                            Didn’t receive OTP? 
                            <button id="resendOtpBtn" class="btn btn-link text-decoration-none" disabled>
                                Resend OTP in <span id="timer">30</span>s
                            </button>
                        </p>

                        <button type="submit" class="btn btn-primary main-gradient w-100">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Timer for Resend OTP
    let countdown = 30;
    let resendBtn = document.getElementById("resendOtpBtn");
    let timer = document.getElementById("timer");

    let interval = setInterval(() => {
        countdown--;
        timer.innerText = countdown;

        if (countdown <= 0) {
            clearInterval(interval);
            resendBtn.disabled = false;
            resendBtn.innerText = "Resend OTP";
            resendBtn.onclick = function() {
                window.location.href = "{{ route('resendOtp') }}";
            };
        }
    }, 1000);
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
