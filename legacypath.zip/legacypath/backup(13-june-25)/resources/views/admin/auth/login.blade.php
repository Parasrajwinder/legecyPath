

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>LegacyPath</title>
    <link rel="icon" type="image/x-icon" href="{{asset('public/public//images/favicon.png')}}">
    <link href="{{asset('public/Assets/css/bootstrap.min.css')}}" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('public/Assets/css/style.css')}}">
  </head>
  <body>
    
    <div class="login_box h-100 d-flex align-items-center">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-5">
            <div class="login_form">
              <div class="text-center">
                <img src="{{asset('public/Assets/images/legacy-path-logo.png')}}" alt="" class="mb-4">
              <h1>Sign in to your account</h1>
              <p class="mb-3">Please enter your email or password below:</p>
              </div>

              <form method="POST" action="{{ route('post.login') }}">
                    @csrf
                <div class="mb-3">
                  <label for="exampleInputEmail1" class="form-label text_black fw-500 font-14">Email</label>
                  <input type="email" name="email" class="form-control" placeholder="Enter email address">
                  @if ($errors->has('email'))
                    <span class="error text-danger">
                        <i>{{ $errors->first('email') }}</i>
                    </span>
                    @endif
                </div>
                <div class="mb-3 position-relative">
              <label for="password-field" class="form-label text_black fw-500 font-14">Password</label>
              <input type="password" id="password-field" name="password" class="form-control" placeholder="Enter password">
                @if ($errors->has('password'))
                        <span class="error text-danger">
                            <i>{{ $errors->first('password') }}</i>
                        </span>
                    @endif
                    
              <!-- Eye Icon Button -->
              <span class="eye-icon" id="toggle-password" style="cursor: pointer; position: absolute; right: 15px; top:56px ; transform: translateY(-50%);">
                <img id="eye-icon" src="{{asset('public/Assets/images/eye-open.svg')}}" alt="Toggle Password">
              </span>
            </div>
                </div>
                <div class="d-flex justify-content-between">
                <div class="mb-4 form-check">
                <!--<input type="checkbox" class="form-check-input" id="remember" name="remember">-->
                <!--<label class="form-check-label" for="remember">Remember me</label>-->
                </div>
                  <a href="{{ route('showForgotPassword')}}" class="theme_bg fw-500">Forgot password?</a>
                </div>
                
                <button type="submit" class="btn btn-primary main-gradient w-100" >Login</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="{{asset('public/Assets/js/bootstrap.bundle.min.js')}}" ></script>
<script>
  document.addEventListener("DOMContentLoaded", function () {
    let passwordField = document.getElementById("password-field");
    let eyeIcon = document.getElementById("eye-icon");
    let togglePassword = document.getElementById("toggle-password");

    togglePassword.addEventListener("click", function () {
      if (passwordField.type === "password") {
        passwordField.type = "text";
        eyeIcon.src = "{{asset('public/Assets/images/eye-slash.svg')}}"; 
      } else {
        passwordField.type = "password";
        eyeIcon.src = "{{asset('public/Assets/images/eye-open.svg')}}";
      }
    });
  });
</script>


  </body>
</html>


