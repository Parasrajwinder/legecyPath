@extends('layouts.master')
@section('content')

            <!-- Page content-->

            <div class="Main_contant_wrap">
              <div class="container-fluid">
                <div class="content-wrapper ">
                  <div class="mb-3 bg-white rounded15 p-4 position-relative col-lg-6 mx-auto border_1 ">
                    <div class="d-flex align-items-center mb-4">
                      <nav aria-label="breadcrumb" class="breadcrumb-block">
                        <ol class="breadcrumb mb-0 pb-0">
                          <li class="breadcrumb-item">Change Password</li>
                        </ol>
                      </nav>
                    </div>
                    <div class="card w-100 pt-3 password">
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                
                    @if (session('success')) 
                        <div class="alert alert-success">
                            {{ session('success') }}
                        </div>
                      @endif
                        
                        <form action="{{route('password.update')}}" method="POST">
                            @csrf
                             <div class="mb-3 position-relative">
                                <label class="form-label text_black fw-500 font-14">Old Password</label>
                                <input type="text" name="password" class="form-control" placeholder="Enter old password">
                                <span class="eye-icon">
                                  <img src="/Assets/images/eye-open.svg" alt="">
                                </span>
                             </div>
                            <div class="mb-3 position-relative">
                                <label class="form-label text_black fw-500 font-14">New Password</label>
                                <input type="text" name="new_password" class="form-control" placeholder="Enter new password">
                                <span class="eye-icon">
                                  <img src="/Assets/images/eye-open.svg" alt="">
                                </span>
                            </div>
                            <div class="mb-3 position-relative">
                                <label class="form-label text_black fw-500 font-14">Confirm Password</label>
                                <input type="text" name="confirm_password" class="form-control" placeholder="Confirm password">
                                <span class="eye-icon">
                                  <img src="/Assets/images/eye-open.svg" alt="">
                                </span>
                            </div>
                            <div class="d-flex  justify-content-end">
                                <button type="submit" class="btn btn-primary main-gradient">Create</button>
                            </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>

@endsection