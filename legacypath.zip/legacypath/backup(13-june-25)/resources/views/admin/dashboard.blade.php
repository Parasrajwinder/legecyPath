@extends('layouts.master')
@section('content')


      <!-- Page content-->

      <div class="Main_contant_wrap">
        <div class="container-fluid">
          <div class="content-wrapper" id="dashboard">
            <div class="dashbaord_data row">
              <div class="col-12 col-xl-4 mt-2">
                <div class="btn-flex p-4 gradient01 box card-animate d-flex align-items-end">
                  <div class="desc_blk">
                    <h3 class="fs-18 pb-3">Number of Active User</h3>
                    <h2 class="mb-0 fw-600">{{ number_format($activeUsersCount) }}</h2>
                    <!--<p class="mt-1 mb-0 fs-14 pt-3">-->
                    <!--  <span class="bg_green">50% <img src="{{asset('public/Assets/images/right-arrow.svg')}}" alt="" />-->
                    <!--  </span> increase last month-->
                    <!--</p>-->
                  </div>
                </div>
              </div>

              <div class="col-12 col-xl-4 mt-2">
                <div class="btn-flex p-4 gradient02 box card-animate d-flex align-items-end">
                  <div class="desc_blk">
                    <h3 class="fs-18 pb-3">Total Users</h3>
                    <h2 class="mb-0 fw-600">{{ number_format($totalUsersCount) }}</h2>
                    <!--<p class="mt-1 mb-0 fs-14 pt-3">-->
                    <!--  <span class="bg_green">50% <img src="{{asset('public/Assets/images/right-arrow.svg')}}" alt="" />-->
                    <!--  </span> increase last month-->
                    <!--</p>-->
                  </div>
                </div>
              </div>

              <div class="col-12 col-xl-4 mt-2">
                <div class="btn-flex p-4 gradient03 box card-animate d-flex align-items-end">
                  <div class="desc_blk">
                    <h3 class="fs-18 pb-3">Total revenue Generated</h3>
                    <h2 class="mb-0 fw-600">${{ number_format($totalRevenue) }}</h2>
                    <!--<p class="mt-1 mb-0 fs-14 pt-3">-->
                    <!--  <span class="bg_green">50% <img src="{{asset('public/Assets/images/right-arrow.svg')}}" alt="" />-->
                    <!--  </span> increase last month-->
                    <!--</p>-->
                  </div>
                </div>
              </div>

              <div class="col-lg-6 mt-4">
                <div class="p-4 mb-3 bg-white rounded15 Shadow_01">
                  <h5 class="m-0 fw-600 fs-20 d-flex align-items-center mb-4">Total Active users
                    <span class="ms-auto">
                      <!--<select id="inputState" class="form-select border-0 fs-14">-->
                      <!--  <option selected>Yearly</option>-->
                      <!--  <option>2011</option>-->
                      <!--  <option>2010</option>-->
                      <!--</select>-->
                    </span>
                  </h5>
                  <canvas id="chart" width="600" height="300"></canvas>
                </div>
              </div>
              <div class="col-lg-6 mt-4">
                <div class="p-4 mb-3 bg-white rounded15 Shadow_01">
                  <h5 class="m-0 fw-600 fs-20 d-flex align-items-center mb-4">Total revenue Generated
                    <span class="ms-auto">
                      <!--<select id="inputState" class="form-select border-0 fs-14">-->
                      <!--  <option selected>Yearly</option>-->
                      <!--  <option>2011</option>-->
                      <!--  <option>2010</option>-->
                      <!--</select>-->
                    </span>
                  </h5>
                  <canvas id="bar" width="600" height="300"></canvas>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>


@endsection

@section('script')

<script>
    const revenueLabels = {!! json_encode(array_keys($revenueByYear)) !!};
    const revenueData = {!! json_encode(array_values($revenueByYear)) !!};

    const userLabels = {!! json_encode(array_keys($activeUsersByYear)) !!};
    const userData = {!! json_encode(array_values($activeUsersByYear)) !!};
</script>

 <script>
        let ctx = document.getElementById("chart").getContext('2d');

        var gradientStroke = ctx.createLinearGradient(500, 0, 100, 0);
        gradientStroke.addColorStop(0, "#C58C6E");
        gradientStroke.addColorStop(1, "#C58C6E");

        var gradientBkgrd = ctx.createLinearGradient(0, 100, 0, 400);
        gradientBkgrd.addColorStop(0, "rgba(197,140,110, 0.2)");
        gradientBkgrd.addColorStop(1, "rgba(197,140,110, 0)");

        let draw = Chart.controllers.line.prototype.draw;
        Chart.controllers.line = Chart.controllers.line.extend({
          draw: function () {
            draw.apply(this, arguments);
            let ctx = this.chart.chart.ctx;
            let _stroke = ctx.stroke;
            ctx.stroke = function () {
              ctx.save();
              //ctx.shadowColor = 'rgba(244,94,132,0.8)';
              ctx.shadowBlur = 8;
              ctx.shadowOffsetX = 0;
              ctx.shadowOffsetY = 6;
              _stroke.apply(this, arguments)
              ctx.restore();
            }
          }
        });

        var chart = new Chart(ctx, {
          // The type of chart we want to create
          type: 'line',

          // The data for our dataset
          data: {
            labels: userLabels,
            datasets: [{
              label: "Active Users",
              backgroundColor: gradientBkgrd,
              borderColor: gradientStroke,
              data: userData,

              pointBorderWidth: 0,
              pointHoverRadius: 8,
              pointHoverBackgroundColor: gradientStroke,
              pointHoverBorderColor: "#787D6A",
              pointHoverBorderWidth: 4,
              pointRadius: 1,
              borderWidth: 3,
              pointHitRadius: 16,
            }]
          },

          // Configuration options go here
          options: {
            tooltips: {
              backgroundColor: '#fff',
              displayColors: false,
              titleFontColor: '#000',
              bodyFontColor: '#000'

            },
            legend: {
              display: false
            },
            scales: {
              xAxes: [{
                gridLines: {
                  display: false
                }
              }],
              yAxes: [{
                ticks: {
                  // Include a dollar sign in the ticks
                  callback: function (value, index, values) {
                    return (value) ;
                  }
                }
              }],
            }
          }
        });
      </script>

      <script>
        const ctx2 = document.getElementById('bar');

        new Chart(ctx2, {
          type: 'bar',
          data: {
            labels: revenueLabels,
            datasets: [{
              label: 'Amount',
              data: revenueData, 
              backgroundColor: [
                '#787D6A',
                '#787D6A',
                '#787D6A',
                '#787D6A',
                '#787D6A',
                '#787D6A',
                '#787D6A',
                '#787D6A'
              ],
              maxBarThickness: 30,
              borderRadius: 10,
              borderWidth: 1
            }]
          },
          options: {
            tooltips: {
              backgroundColor: '#fff',
              displayColors: false,
              titleFontColor: '#000',
              bodyFontColor: '#000'

            },
            legend: {
              display: false
            },
            scales: {
              xAxes: [{
                gridLines: {
                  display: false
                }
              }],
              yAxes: [{
                ticks: {
                  // Include a dollar sign in the ticks
                  callback: function (value, index, values) {
                    return (value);
                  }
                }
              }],
            }
          }
        });
      </script>


      <script>

        var options1 = {

          type: 'doughnut',

          data: {

            labels: ["Red", "Green"],

            datasets: [

              {

                label: '# of Votes',

                data: [33, 33],

                barThickness: 3,

                backgroundColor: [

                  'rgba(231, 76, 60, 1)',

                  'rgba(255, 164, 46, 1)',

                  'rgba(46, 204, 113, 1)'

                ],

                borderColor: [

                  'rgba(255, 255, 255 ,1)',

                  'rgba(255, 255, 255 ,1)',

                  'rgba(255, 255, 255 ,1)'

                ],

                borderWidth: .1

              }

            ]

          },

          options: {

            rotation: 1 * Math.PI,

            circumference: 1 * Math.PI,

            legend: {

              display: false

            },

            tooltip: {

              enabled: false

            },

            cutoutPercentage: 90

          }

        }



        var ctx1 = document.getElementById('chartJSContainer').getContext('2d');

        new Chart(ctx1, options1);

      </script>
      
      @endsection