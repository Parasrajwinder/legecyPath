@extends('layouts.master')
@section('content')
    <!-- Page content-->
    <div class="Main_contant_wrap">
        <div class="container-fluid">
            <div class="content-wrapper">
                <div class="mb-3 bg-white rounded15 p-4 position-relative border_1">
                    <div class="d-flex align-items-center pb-3">
                        <div>
                            <h5 class="text_main_black fw-600 mb-0">Report Management</h5>
                        </div>
                        <div class="d-flex align-items-center gap-2 ms-auto">
                            <!--<div class="search-btn">-->
                            <!--    <input type="text" placeholder="Search..." class="form-control">-->
                            <!--</div>-->
                            <a data-bs-toggle="modal" data-bs-target="#AddQoutesModal" type="button"
                                class="btn btn-sm btn-primary w-auto main-gradient">Add</a>
                        </div>
                    </div>
                    <div>
                        <div class="col-lg-12 px-0">
                            <div class="border-0">
                                <div class="card global-shadow warehouse w-100 tbl_scrl table-responsive">
                                    <table class="display w-100 pt-0" id="upcomingReservation">
                                        <thead>
                                            <tr>
                                                <th scope="col">Sr. No.</th>
                                                <th scope="col">Quotes</th>
                                                <th scope="col">Author</th>
                                                <th scope="col">Action</th>
                                            </tr>
                                        </thead>
                                         <tbody id="quotes-table-body">
                                        @foreach ($quotes as $key => $quote)
                                            <tr>
                                                <td>#{{ $key + 1 }}</td>
                                                <td>{{ $quote->quotes }}</td>
                                                <td>{{ $quote->author }}</td>
                                                <td>
                                                    <button class="btn btn-sm btn-primary edit-quote" data-bs-toggle="modal" data-bs-target="#EditQoutesModal" 
                                                        data-id="{{ $quote->id }}" data-quote="{{ $quote->quotes }}" data-author="{{ $quote->author }}">
                                                        Edit
                                                    </button>
                                                    <button type="button" class="btn btn-sm btn-danger delete-quote" onclick="confirmDelete({{ $quote->id }})">Delete</button>
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!--Edit Qoutes Modal -->
    <div class="modal fade" id="EditQoutesModal" tabindex="-1" aria-labelledby="EditQoutesModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="EditQoutesModalLabel">Edit quotes</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif

                    <input type="hidden" id="editQuoteId">
                    <div class="mb-3">
                        <label for="editQuoteText" class="form-label text_black fw-500 font-14">Quotes</label>
                        <textarea id="editQuoteText" rows="5" class="form-control"
                            placeholder="Enter quotes here..."></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="editQuoteAuthor" class="form-label text_black fw-500 font-14">Author</label>
                        <input id="editQuoteAuthor" class="form-control" placeholder="Enter author name...">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-grey-block" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary main-gradient" id="updateQuoteBtn">Save</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Quotes Modal -->
    
<div class="modal fade" id="AddQoutesModal" tabindex="-1" aria-labelledby="AddQoutesModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="AddQoutesModalLabel">Add quotes</h1>
                <button id="openAddQuoteModal" type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="errorContainer">
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                </div>

                <form id="addQuoteForm" method="post" action="{{route('addQuote')}}">
                    @csrf
                    <div class="mb-3">
                        <label for="addQuoteText" class="form-label text_black fw-500 font-14">Quotes</label>
                        <textarea id="addQuoteText" name="quotes" rows="5" class="form-control" placeholder="Enter quotes here..." required></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="addQuoteAuthor" class="form-label text_black fw-500 font-14">Author</label>
                        <input id="addQuoteAuthor" name="author" class="form-control" placeholder="Enter author name..." required>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-grey-block" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary main-gradient">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>




    

@endsection
@section('script')
@if ($errors->any())
    <script>
        $(document).ready(function() {
            $('#AddQoutesModal').modal('show');
        });
    </script>
@endif

<script>
    $(document).ready(function () {
        $('#openAddQuoteModal').on('click', function () {
            $('#addQuoteForm')[0].reset();
            $('#errorContainer').html('');
        });

        // Reset form and errors when modal is hidden (on clicking Close or outside modal)
        $('#AddQoutesModal').on('hidden.bs.modal', function () {
            $('#addQuoteForm')[0].reset();
            $('#errorContainer').html('');
        });
    });
</script>



<script>
  function confirmDelete(userId) {
    const csrfToken = $('meta[name="csrf-token"]').attr('content');

    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: "{{ route('destroyQuote', ':id') }}".replace(':id', userId),
                type: 'DELETE', 
                headers: {
                    'X-CSRF-TOKEN': csrfToken, 
                },
                success: function(response) {
                    Swal.fire(
                        'Deleted!',
                        'The Quote has been deleted.',
                        'success'
                    ).then(() => {
                    window.location.reload();
                    });
                },
                error: function(xhr) {
                    console.log(xhr);
                    Swal.fire(
                        'Error!',
                        'There was an error deleting the Quote.',
                        'error'
                    );
                }
            });
        }
    });
}
</script>

<script>
    $(document).ready(function () {
    $('.edit-quote').on('click', function () {
        let quoteId = $(this).data('id');
        let quoteText = $(this).data('quote');
        let quoteAuthor = $(this).data('author');

        $('#editQuoteId').val(quoteId);
        $('#editQuoteText').val(quoteText);
        $('#editQuoteAuthor').val(quoteAuthor);
    });

    $('#updateQuoteBtn').on('click', function () {
        let quoteId = $('#editQuoteId').val();
        let updatedText = $('#editQuoteText').val();
        let updatedAuthor = $('#editQuoteAuthor').val();

        $.ajax({
    url: "{{route('updateQuote')}}",
    type: 'POST',
    data: {
        _token: '{{ csrf_token() }}',
        id: quoteId,
        quotes: updatedText,
        author: updatedAuthor
    },
    success: function (response) {
        if (response.success) {
            Swal.fire({
                title: 'Success!',
                text: 'Quote updated successfully!',
                icon: 'success',
                confirmButtonText: 'OK'
            }).then(() => {
                location.reload();
            });
        } else {
            Swal.fire({
                title: 'Error!',
                text: 'Failed to update quote.',
                icon: 'error',
                confirmButtonText: 'OK'
            });
        }
    },
    error: function () {
        Swal.fire({
            title: 'Oops!',
            text: 'Something went wrong. Try again.',
            icon: 'error',
            confirmButtonText: 'OK'
        });
    }
});

    });
});

</script>

@endsection
