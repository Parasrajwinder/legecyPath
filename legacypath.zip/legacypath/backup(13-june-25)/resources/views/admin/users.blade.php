@extends('layouts.master')
@section('content')

      <!-- Page content-->

      <div class="Main_contant_wrap">
        <div class="container-fluid">
          <div class="content-wrapper">
            <div class="mb-3 bg-white rounded15 p-4 position-relative border_1">
              <div class="d-flex align-items-center pb-3">
                <div>
                  <h5 class="text_main_black fw-600 mb-0">Users Management</h5>
                </div>
                <div class="d-flex align-items-center gap-2 ms-auto">
                  <!--<div class="search-btn">-->
                  <!--  <input type="text" placeholder="Search..." class="form-control">-->
                  <!--</div>-->
                </div>
              </div>
              <div>
                <div class="col-lg-12 px-0">
                  <div class="border-0">
                    <div class="card global-shadow warehouse w-100 tbl_scrl table-responsive">
                      <table class="isplay w-100 pt-0" id="upcomingReservation">
                        <thead>
                          <tr>
                            <th scope="col">user name </th>
                            <th scope="col">Email address</th>
                            <th scope="col">Date of birth</th>
                            <th scope="col">Phone number</th>
                            <th scope="col">Gender</th>
                            <th scope="col">Status</th>
                            <th scope="col">Action</th>
                          </tr>
                        </thead>

                        <tbody>
                          
                          @foreach($users as $user)
                            <tr>
                          
                            <td>
                        <img src="{{ asset('storage/app/public/user_images') }}/{{$user->profile_img}}"onerror="this.onerror=null; this.src='{{ asset('public/Assets/images/UserCircle.svg') }}';" alt="User Profile Image"
                                
                        class="rounded-circle" width="40" height="40">
                                {{ $user->first_name }} {{ $user->last_name }}</td>
                            <td>{{$user->email}}</td>
                            <td>{{$user->date_of_birth}}</td>
                            <td>{{$user->country_code}} {{$user->phone_number}}</td>
                            <td>{{$user->gender}}</td>
                            <td> <span class="badges active-badge">{{$user->status}}</span> </td>

                            <td>
                              <div class="d-flex align-items-center gap-1">
                                <a href="{{route('users.details',['id' => $user->id])}}" type="button"
                                  class="btn btn-sm btn-primary w-auto main-gradient"> View details</a>
                              </div>
                            </td>
                          </tr>
                        @endforeach
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
      @endsection
      

