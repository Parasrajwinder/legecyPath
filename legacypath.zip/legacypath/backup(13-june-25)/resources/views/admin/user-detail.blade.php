@extends('layouts.master')
@section('content')

<!-- Page content-->
<div class="Main_contant_wrap">
    <div class="container-fluid">
        <div class="content-wrapper">
            <div class="row justify-content-center">
                <div class="col-lg-7">
                    <div class="mb-3 bg-white rounded15 p-4 position-relative border_1">
                        <div class="d-flex align-items-center justify-content-between pb-4 border-bottom">
                            <h5 class="fw-600 text_main_black mb-0">Users Details</h5>
                            <div>
                                   
                                    <button  class="btn btn-outline-danger btn-sm toggle-status" 
                                            data-id="{{ $user->id }}" data-status="{{ $user->status }}">
                                        {{ $user->status == 'Active' ? 'Suspend' : 'Activate' }}
                                    </button>



                                    <button type="button" class="btn btn-outline-info btn-sm" onclick="confirmDelete({{ $user->id }})">Delete</button>
                            </div>
                        </div>
                        
                        <div class="d-flex align-items-center gap-3 mt-4 user-details">
                            <div class="avtar_02">
                                <img src="{{ asset('storage/app/public/user_images') }}/{{$user->profile_img}}" onerror="this.onerror=null; this.src='{{ asset('public/Assets/images/user_photo.svg') }}';" width="80px" alt="User Profile Image">
                            </div>
                            <div>
                                <h4 class="fw-600 text_main_black mb-1">{{ $user->name }}</h4>
                                <p class="mb-0 text_gray">{{ $user->email }}</p>
                            </div>
                        </div>

                        <div class="d-flex gap-3 my-3 align-items-center">
                            <div class="icons-40">
                                <img src="{{asset('public/Assets/images/call.svg')}}" alt="">
                            </div>
                            
                            <div>
                                <p class="mb-0"><small>Phone number</small></p>
                                <h6 class="mb-0">{{$user->country_code}}{{ $user->phone_number }}</h6>
                            </div>
                        </div>

                        <div class="d-flex gap-3 my-3 align-items-center">
                            <div class="icons-40">
                                <img src="{{asset('public/Assets/images/Globe.svg')}}" alt="">
                            </div>
                            
                            <div>
                                <p class="mb-0"><small>Country</small></p>
                                <h6 class="mb-0">{{ $user->country ?? 'N/A' }}</h6>
                            </div>
                        </div>

                        <div class="d-flex gap-3 my-3 align-items-center">
                            <div class="icons-40">
                                <img src="{{asset('public/Assets/images/Cake.svg')}}" alt="">
                            </div>
                            <div>
                                <p class="mb-0"><small>Date of birth</small></p>
                                <h6 class="mb-0">{{ $user->date_of_birth ?? 'N/A' }}</h6>
                            </div>
                        </div>

                        <div class="d-flex gap-3 my-3 align-items-center">
                            <div class="icons-40">
                                <img src="{{asset('public/Assets/images/GenderMale.svg')}}" alt="">
                            </div>
                            <div>
                                <p class="mb-0"><small>Gender</small></p>
                                <h6 class="mb-0">{{ ucfirst($user->gender) }}</h6>
                            </div>
                        </div>

                        <div class="subscription gradient03 d-flex align-items-center justify-content-between">
                            <div>
                                <h4 class="fw-600">${{ $user->subscription_price ?? '0.00' }}/Year</h4>
                                <p class="mb-0">Renewal date: {{ $user->subscription_renewal_date ?? 'N/A' }}</p>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


@endsection

@section('script')

<script>
  function confirmDelete(userId) {
    const csrfToken = $('meta[name="csrf-token"]').attr('content');

    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: "{{ route('users.destroy', ':id') }}".replace(':id', userId),
                type: 'GET', 
                headers: {
                    'X-CSRF-TOKEN': csrfToken, 
                },
                success: function(response) {
                    Swal.fire(
                        'Deleted!',
                        'The user has been deleted.',
                        'success'
                    ).then(() => {
                        window.location.href="{{route('getUsers')}}";
                    });
                },
                error: function(xhr) {
                    console.log(xhr);
                    Swal.fire(
                        'Error!',
                        'There was an error deleting the user.',
                        'error'
                    );
                }
            });
        }
    });
}
</script>

<script>
  $(document).on("click", ".toggle-status", function () {
          let button = $(this);
          let userId = button.data("id");
          let currentStatus = button.data("status");
          let newStatus = currentStatus === 'Active' ? 'Suspended' : 'Active';
          const csrfToken = $('meta[name="csrf-token"]').attr('content');

          Swal.fire({
              title: 'Are you sure?',
              text: `You are about to ${newStatus === 'Active' ? 'Activate' : 'Suspend'} this user!`,
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: `Yes, ${newStatus === 'Active' ? 'Activate' : 'Suspend'}!`
          }).then((result) => {
              if (result.isConfirmed) {
                  $.ajax({
                      url: "{{ route('users.suspend') }}",
                      type: "POST",
                      data: {
                          id: userId,
                          status: newStatus,
                      },
                      headers: {
                          "X-CSRF-TOKEN": csrfToken,
                      },
                      success: function (response) {
                          Swal.fire(
                              'Success!',
                              `User has been ${newStatus === 'Active' ? 'Activated' : 'Suspended'}.`,
                              'success'
                          );
                          button.text(newStatus === 'Active' ? 'Suspend' : 'Activate');
                          button.data("status", newStatus);
                      },
                      error: function (xhr) {
                          console.log(xhr);
                          Swal.fire(
                              'Error!',
                              'Something went wrong.',
                              'error'
                          );
                      }
                  });
              }
          });
  });
</script>
@endsection
