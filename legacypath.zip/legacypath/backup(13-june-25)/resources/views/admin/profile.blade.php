@extends('layouts.master')
@section('content')

<!-- Page content-->
<div class="Main_contant_wrap">
    <div class="container-fluid">
        <div class="content-wrapper">
            <div class="mb-3 bg-white rounded15 p-4 position-relative col-lg-6 mx-auto border_1">
                <div class="d-flex align-items-center mb-4">
                    <nav aria-label="breadcrumb" class="breadcrumb-block">
                        <ol class="breadcrumb mb-0 pb-0">
                            <li class="breadcrumb-item">Profile</li>
                        </ol>
                    </nav>
                </div>
                <div class="card w-100 pt-3">
                    @if(session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{ session('success') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    @endif
                    <form action="{{ route('profile.update') }}" method="POST" enctype="multipart/form-data">
                        @csrf

                        <div class="avatar-upload">
                            <div class="avatar-edit">
                                <input type='file' id="imageUpload" name="photo" accept=".png, .jpg, .jpeg" />
                                <label for="imageUpload">
                                    <svg width="21" height="20" viewBox="0 0 21 20" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path
                                            d="M13.2009 6.66632L11.5491 5.01448V12.2913C11.5491 12.8667 11.0828 13.333 10.5074 13.333C9.93218 13.333 9.46576 12.8667 9.46576 12.2913V5.01448L7.81388 6.66637C7.40709 7.07317 6.74754 7.07317 6.34074 6.66637C5.93395 6.25957 5.93395 5.60002 6.34074 5.19323L9.77085 1.76311C9.96618 1.56776 10.2312 1.45801 10.5074 1.45801C10.7837 1.45801 11.0487 1.56776 11.244 1.76311L14.6741 5.19318C15.0808 5.59997 15.0808 6.25952 14.6741 6.66632C14.2673 7.07312 13.6078 7.07312 13.2009 6.66632Z"
                                            fill="#0F172A" />
                                        <path
                                            d="M17.1741 11.666C16.5987 11.666 16.1324 12.1323 16.1324 12.7077V15.6243H4.88241V12.7077C4.88241 12.1323 4.41604 11.666 3.84074 11.666C3.26544 11.666 2.79907 12.1323 2.79907 12.7077V15.8327C2.79907 16.8682 3.63854 17.7077 4.67407 17.7077H16.3407C17.3762 17.7077 18.2157 16.8682 18.2157 15.8327V12.7077C18.2157 12.1323 17.7493 11.666 17.1741 11.666Z"
                                            fill="#0F172A" />
                                    </svg>
                                </label>
                            </div>
                            <div class="avatar-preview">
                                <div id="imagePreview"
                                    style="background-image: url('{{ Auth::guard('admin')->user()->photo ? asset('storage/app/public/admin/' . Auth::guard('admin')->user()->photo) : 'http://i.pravatar.cc/500?img=7' }}');">
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label text_black fw-500 font-14">First name</label>
                            <input type="text" class="form-control" name="firstname" placeholder="Enter first name"
                                value="{{ Auth::guard('admin')->user()->firstname }}">
                        </div>
                        <div class="mb-3">
                            <label class="form-label text_black fw-500 font-14">Last name</label>
                            <input type="text" class="form-control" name="lastname" placeholder="Enter last name"
                                value="{{ Auth::guard('admin')->user()->lastname }}">
                        </div>
                        <div class="mb-3">
                            <label class="form-label text_black fw-500 font-14">Email address</label>
                            <input type="text" class="form-control" name="email" placeholder=""
                                value="{{ Auth::guard('admin')->user()->email }}" disabled>
                        </div>
                        <div class="d-flex justify-content-end">
                            <button type="submit" class="btn btn-primary main-gradient">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById('imageUpload').addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('imagePreview').style.backgroundImage = 'url(' + e.target.result + ')';
            }
            reader.readAsDataURL(file);
        }
    });
</script>

@endsection

