@extends('layouts.master')

@section('content')
<style>
    div#loader {
    position: absolute;
    left: 0;
    right: 0;
    width: 47px;
    margin: auto;
    top: 50%;
    bottom: 0;
    z-index:99999;
}
</style>
<!-- Page content-->
<div class="Main_contant_wrap">
    <div class="container-fluid">
        <div class="content-wrapper">
            <div class="mb-3 bg-white rounded15 p-4 position-relative border_1">
                <div class="d-flex align-items-center pb-3">
                    <div>
                        <h5 class="text_main_black fw-600 mb-0">Report Management</h5>
                    </div>
                </div>
                <div>
                    <div class="col-lg-12 px-0">
                        <div class="border-0">
                            <div class="card global-shadow warehouse w-100 tbl_scrl table-responsive">
                                <table class="display w-100 pt-0" id="upcomingReservation">
                                    <thead>
                                        <tr>
                                            <th scope="col">Report ID</th>
                                            <th scope="col">User name</th>
                                            <th scope="col">Email address</th>
                                            <th scope="col">Message</th>
                                            <th scope="col">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($reports as $key => $report)
                                            <tr>
                                                <td>#{{ $key + 1 }}</td>
                                                <td>
                                                    <div class="d-flex align-items-center gap-2">
                                                        {{ $report->full_name ?? 'N/A' }}
                                                    </div>
                                                </td>
                                                <td>{{ $report->email ?? 'N/A' }}</td>
                                                <td class="white-space-wrap">{{ $report->message ?? 'N/A' }}</td>
                                                <td>
                                                    <div class="d-flex align-items-center gap-1">
                                                        <a data-bs-toggle="modal" 
                                                           data-bs-target="#exampleModal" 
                                                           data-id="{{ $report->id }}" 
                                                           class="btn btn-sm btn-primary w-auto main-gradient reply-btn">
                                                           Reply
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                        <!--@if($reports->isEmpty())-->
                                        <!--    <tr>-->
                                        <!--        <td colspan="5" class="text-center">No reports found.</td>-->
                                        <!--    </tr>-->
                                        <!--@endif-->
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Reply Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-dialog-centered">
        <div class="modal-content">
            <form id="replyForm">
                @csrf
                <input type="hidden" name="userid" id="userid">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Send message</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label text_black fw-500 font-14">Reply</label>
                        <textarea name="replymssagee" id="replymssagee" rows="5" class="form-control" placeholder="Enter message..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary"
                        data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary main-gradient">Send</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="loader" style="display:none;">
    <!-- Simple loader style, customize as needed -->
    <div class="spinner-border text-primary" role="status">
        <span class="visually-hidden">Sending...</span>
    </div>
</div>


@endsection

@section('script')
<script>
    $(document).ready(function () {

        $('.reply-btn').on('click', function () {
            const userId = $(this).data('id');
            $('#userid').val(userId);
            $('#replymssagee').val('');
        });


        $('#replyForm').on('submit', function (e) {
            e.preventDefault();

            const formData = {
                _token: $('input[name="_token"]').val(),
                userid: $('#userid').val(),
                replymssagee: $('#replymssagee').val()
            };

$.ajax({
    url: "{{ route('reply.user') }}",
    method: "POST",
    data: formData,
    
       beforeSend: function () {
        $('#loader').show();
    },
    // success: function (response) {
    //     $('#exampleModal').modal('hide');
    //     $('#loader').hide();
    
    
    success: function (response) {
        $('#exampleModal').modal('hide');

        Swal.fire({
            icon: 'success',
            title: 'Success!',
            text: 'Replied successfully!',
            timer: 2000,
            showConfirmButton: false
        }).then(() => {
            location.reload();
        });
    },
    error: function (xhr) {
        
        $('#loader').hide(); // Hide loader on error
                
        let errorMsg = 'Something went wrong!';
        if (xhr.responseJSON && xhr.responseJSON.message) {
            errorMsg = xhr.responseJSON.message;
        }

        Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: errorMsg,
        });
    }
});

        });
    });
</script>
@endsection
