<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <title>LegacyPath</title>
  <link href="{{asset('public/Assets/css/bootstrap.min.css')}}" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,100..900;1,100..900&display=swap"
    rel="stylesheet">
  <link rel="stylesheet" href="{{asset('public/Assets/css/style.css')}}">
 
  
  <link rel="icon" type="image/x-icon" href="{{asset('public/Assets/images/favicon.png')}}">
  <!-- datatable css-->
  <link rel="stylesheet" href="https://cdn.datatables.net/2.2.2/css/dataTables.dataTables.min.css" />
  <link rel="stylesheet" href="{{asset('public/Assets/css/jquery.dataTables.min.css')}}" />
  <link rel="stylesheet" href="{{asset('public/Assets/css/dataTables.responsive.css')}}">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.css">
 <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.6/dist/sweetalert2.min.css" rel="stylesheet">  
</head>

<body>

        @php
        $admin = Auth::guard('admin')->user();
         @endphp

  <div class="d-flex" id="wrapper">

    <div class="overlay"></div>
 
  @include('layouts.sidebar')


    <!-- Page content wrapper-->

    <div id="page-content-wrapper">
      <!-- Top navigation-->
      <div class="">
        <nav class="navbar navbar-expand-lg navbar-light fixed-top Shadow_02">
          <button class="btn ps-2" id="sidebarToggle">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M5 7H19" stroke="#0D0000" stroke-width="2" stroke-linecap="round" />
              <path d="M5 12H19" stroke="#0D0000" stroke-width="2" stroke-linecap="round" />
              <path d="M5 17H19" stroke="#0D0000" stroke-width="2" stroke-linecap="round" />
            </svg>

          </button>
          <h5 class="mb-0 pb-0 fw-600">@if(Auth::guard('admin')->check())
                    <p>Welcome, {{ Auth::guard('admin')->user()->firstname }} {{ Auth::guard('admin')->user()->lastname }}</p>
                @else
                    <p>Not Logged In</p>
                @endif</h5>
          <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle user-profile d-flex align-items-center" id="navbarDropdown" href="#"
                role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <div class="d-flex align-items-center me-3">
                  <div class="avtar_01 me-2">
          
                    <img src="{{ Auth::guard('admin')->user()->photo ? asset('storage/app/public/admin/' . Auth::guard('admin')->user()->photo) : asset('Assets/images/Avatar.png') }}" alt="Admin Avatar">

                  </div>
                  <div class="">
                    <h6 class="mb-0 colorBlack fw-600 lHeight">{{ Auth::guard('admin')->user()->firstname }} {{ Auth::guard('admin')->user()->lastname }}</h6>
                    <p class="fs-12 mb-0">{{ Auth::guard('admin')->user()->email }}</p>
                  </div>
                </div>
              </a>

              <div class="dropdown-menu dropdown-menu-end custom-dropdown" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="{{route('profile')}}"> Profile</a>
                <a class="dropdown-item" href="{{route('showChangePassword')}}"> Change password</a>
              </div>
            </li>
          </ul>
        </nav>
      </div>



      <!-- Page content-->

       @yield('content')




      <!-- Bootstrap core JS-->

      <script src="{{asset('public/Assets/js/bootstrap.bundle.min.js')}}"></script>

    
      <script src="{{asset('public/Assets/js/jquery-3.6.1.min.js')}}"></script>

      <script src="https://cdn.datatables.net/2.2.2/js/dataTables.min.js"></script>

      <script src="{{asset('public/Assets/js/dataTables.responsive.js')}}"></script>

      <!-- Core theme JS-->

      <script src="{{asset('public/Assets/js/main.js')}}"></script>


      <script src="{{asset('public/Assets/js/chart.js')}}"></script>
      
      <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.6/dist/sweetalert2.all.min.js"></script>
      
      <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

      <script>
        $(document).ready(function () {
            new DataTable('#upcomingReservation', {
            ordering: false
            });
          /*$('#upcomingReservation').dataTable({

            Response: true,
            // paging: true,
            searching: true,
            order: [[16, 'desc']],
            
            language: {

              paginate: {

                next: <img src="{{ asset('public/Assets/images/prev.svg') }}">,
                
                previous: <img src="{{ asset('public/Assets/images/next.svg') }}">

              }

            }

          });*/

        });

      </script>

     @yield('script')
    
</body>



</html>