    <!-- Sidebar-->


    <div class="sidebgleft Shadow_01" id="sidebar-wrapper">
      <div class="sidebar-heading">
        <img src="{{asset('public/Assets/images/logo.png')}}" alt="Logo" class="logo" />
        <button class="btn p-0" id="closeSidebar">
          <svg width="13" height="13" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" clip-rule="evenodd"
              d="M0.707107 11.7071C0.316582 11.3166 0.316582 10.6834 0.707107 10.2929L10.6066 0.393398C10.9971 0.00287454 11.6303 0.00287416 12.0208 
              0.393398C12.4113 0.783923 12.4113 1.41709 12.0208 1.80761L2.12132 11.7071C1.7308 12.0976 1.09763 12.0976 0.707107 11.7071Z" fill="#0D0000">
            </path>
            <path fill-rule="evenodd" clip-rule="evenodd" d="M0.706956 0.707107C1.09748 0.316582 1.73064 0.316582 2.12117 0.707107L12.0207
             10.6066C12.4112 10.9971 12.4112 11.6303 12.0207 12.0208C11.6301 12.4113 10.997 12.4113 10.6065 12.0208L0.706956 2.12132C0.316431 
             1.7308 0.316431 1.09763 0.706956 0.707107Z" fill="#0D0000"></path>
          </svg>
        </button>
      </div>
      <div class="list-group list-group-flush bg-transparent">

        <a class="list-group-item list-group-item-action list-group-item-light  {{ request()->routeIs('dashboard') ? 'active' : '' }}" href="{{route('dashboard')}}">
          <span class="act_icn">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <g clip-path="url(#clip0_2112_10266)">
                <path
                  d="M9.75 4.5H5.25C4.83579 4.5 4.5 4.83579 4.5 5.25V9.75C4.5 10.1642 4.83579 10.5 5.25 10.5H9.75C10.1642 10.5 10.5 10.1642 10.5 9.75V5.25C10.5 4.83579 10.1642 4.5 9.75 4.5Z"
                  stroke="#757575" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                <path
                  d="M18.75 4.5H14.25C13.8358 4.5 13.5 4.83579 13.5 5.25V9.75C13.5 10.1642 13.8358 10.5 14.25 10.5H18.75C19.1642 10.5 19.5 10.1642 19.5 9.75V5.25C19.5 4.83579 19.1642 4.5 18.75 4.5Z"
                  stroke="#757575" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                <path
                  d="M9.75 13.5H5.25C4.83579 13.5 4.5 13.8358 4.5 14.25V18.75C4.5 19.1642 4.83579 19.5 5.25 19.5H9.75C10.1642 19.5 10.5 19.1642 10.5 18.75V14.25C10.5 13.8358 10.1642 13.5 9.75 13.5Z"
                  stroke="#757575" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                <path
                  d="M18.75 13.5H14.25C13.8358 13.5 13.5 13.8358 13.5 14.25V18.75C13.5 19.1642 13.8358 19.5 14.25 19.5H18.75C19.1642 19.5 19.5 19.1642 19.5 18.75V14.25C19.5 13.8358 19.1642 13.5 18.75 13.5Z"
                  stroke="#757575" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
              </g>
              <defs>
                <clipPath id="clip0_2112_10266">
                  <rect width="24" height="24" fill="#757575" />
                </clipPath>
              </defs>
            </svg>
          </span>
          <span>Dashboard</span>
        </a>

        <a class="list-group-item list-group-item-action list-group-item-light {{ request()->routeIs('getUsers') ? 'active' : '' }}" href="{{route('getUsers')}}">
          <span class="menu-icons">
            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
              <g clip-path="url(#clip0_2213_6484)">
                <path
                  d="M1.03235 18.9562C1.7815 17.8043 2.80647 16.8578 4.01422 16.2026C5.22197 15.5474 6.57425 15.2042 7.94829 15.2042C9.32232 15.2042 10.6746 15.5474 11.8824 16.2026C13.0901 16.8578 14.1151 17.8043 14.8642 18.9562"
                  stroke="#757575" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                <path
                  d="M16.1982 15.2062C17.5722 15.2054 18.9246 15.548 20.1324 16.2029C21.3403 16.8578 22.3652 17.8043 23.1142 18.9562"
                  stroke="#757575" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                <path
                  d="M7.94824 15.2062C10.6406 15.2062 12.8232 13.0236 12.8232 10.3312C12.8232 7.63879 10.6406 5.45618 7.94824 5.45618C5.25585 5.45618 3.07324 7.63879 3.07324 10.3312C3.07324 13.0236 5.25585 15.2062 7.94824 15.2062Z"
                  stroke="#757575" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                <path
                  d="M14.3879 5.80305C15.0548 5.53708 15.7722 5.42168 16.4888 5.4651C17.2054 5.50852 17.9036 5.70969 18.5335 6.05424C19.1634 6.39878 19.7093 6.87819 20.1324 7.45822C20.5556 8.03824 20.8453 8.70456 20.981 9.40955C21.1168 10.1146 21.0951 10.8408 20.9176 11.5365C20.7401 12.2321 20.4111 12.88 19.9542 13.4338C19.4973 13.9875 18.9237 14.4336 18.2744 14.74C17.6251 15.0463 16.9162 15.2055 16.1983 15.2062"
                  stroke="#757575" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
              </g>
              <defs>
                <clipPath id="clip0_2213_6484">
                  <rect width="24" height="24" fill="white" transform="translate(0.0732422 0.206177)" />
                </clipPath>
              </defs>
            </svg>


          </span>
          <span>
            User Management
          </span>
        </a>

        <a class="list-group-item list-group-item-action list-group-item-light {{ request()->routeIs('showQuotes') ? 'active' : '' }}" href="{{route('showQuotes')}}">
          <span class="menu-icons">
            <svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
              <g clip-path="url(#clip0_1179_4450)">
              <path d="M11.1636 14.5332H4.52295C4.31575 14.5332 4.11703 14.4509 3.97052 14.3044C3.82401 14.1579 3.7417 13.9592 3.7417 13.752V7.50195C3.7417 7.29475 3.82401 7.09604 3.97052 6.94953C4.11703 6.80301 4.31575 6.7207 4.52295 6.7207H10.3823C10.5895 6.7207 10.7882 6.80301 10.9348 6.94953C11.0813 7.09604 11.1636 7.29475 11.1636 7.50195V16.0957C11.1636 17.1317 10.752 18.1253 10.0195 18.8578C9.2869 19.5904 8.29333 20.002 7.25732 20.002" stroke="#757575" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M22.4917 14.5332H15.8511C15.6439 14.5332 15.4452 14.4509 15.2986 14.3044C15.1521 14.1579 15.0698 13.9592 15.0698 13.752V7.50195C15.0698 7.29475 15.1521 7.09604 15.2986 6.94953C15.4452 6.80301 15.6439 6.7207 15.8511 6.7207H21.7104C21.9176 6.7207 22.1164 6.80301 22.2629 6.94953C22.4094 7.09604 22.4917 7.29475 22.4917 7.50195V16.0957C22.4917 17.1317 22.0801 18.1253 21.3476 18.8578C20.615 19.5904 19.6215 20.002 18.5854 20.002" stroke="#757575" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
              </g>
              <defs>
              <clipPath id="clip0_1179_4450">
              <rect width="25" height="25" fill="white" transform="translate(0.616699 0.470703)"/>
              </clipPath>
              </defs>
              </svg>
              


          </span>
          <span>
            Quotes Management
          </span>
        </a>
        <a class="list-group-item list-group-item-action list-group-item-light {{ request()->routeIs('showReport') ? 'active' : '' }}" href="{{route('showReport')}}">
          <span class="menu-icons">
            <svg width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
              <g clip-path="url(#clip0_2117_10308)">
                <path
                  d="M16.3345 21.4395H5.83447C5.63556 21.4395 5.44479 21.3604 5.30414 21.2198C5.16349 21.0791 5.08447 20.8884 5.08447 20.6895V7.18945C5.08447 6.99054 5.16349 6.79978 5.30414 6.65912C5.44479 6.51847 5.63556 6.43945 5.83447 6.43945H13.3345L17.0845 10.1895V20.6895C17.0845 20.8884 17.0055 21.0791 16.8648 21.2198C16.7242 21.3604 16.5334 21.4395 16.3345 21.4395Z"
                  stroke="#757575" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                <path
                  d="M8.08447 6.43945V4.18945C8.08447 3.99054 8.16349 3.79978 8.30414 3.65912C8.44479 3.51847 8.63556 3.43945 8.83447 3.43945H16.3345L20.0845 7.18945V17.6895C20.0845 17.8884 20.0055 18.0791 19.8648 18.2198C19.7242 18.3604 19.5334 18.4395 19.3345 18.4395H17.0845"
                  stroke="#757575" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
                <path d="M8.83447 14.6895H13.3345" stroke="#757575" stroke-width="1.5" stroke-linecap="round"
                  stroke-linejoin="round" />
                <path d="M8.83447 17.6895H13.3345" stroke="#757575" stroke-width="1.5" stroke-linecap="round"
                  stroke-linejoin="round" />
              </g>
              <defs>
                <clipPath id="clip0_2117_10308">
                  <rect width="24" height="24" fill="white" transform="translate(0.584473 0.439453)" />
                </clipPath>
              </defs>
            </svg>
          </span>
          <span>
            Report Management
          </span>
        </a>

        <a class="list-group-item list-group-item-action list-group-item-light" href="{{route('logout')}}">
          <span class="menu-icons">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <g clip-path="url(#clip0_2117_10314)">
                <path d="M10.5 3.75H4.5V20.25H10.5" stroke="#757575" stroke-width="1.5" stroke-linecap="round"
                  stroke-linejoin="round" />
                <path d="M10.5 12H21" stroke="#757575" stroke-width="1.5" stroke-linecap="round"
                  stroke-linejoin="round" />
                <path d="M17.25 8.25L21 12L17.25 15.75" stroke="#757575" stroke-width="1.5" stroke-linecap="round"
                  stroke-linejoin="round" />
              </g>
              <defs>
                <clipPath id="clip0_2117_10314">
                  <rect width="24" height="24" fill="white" />
                </clipPath>
              </defs>
            </svg>
          </span>
          <span> Logout </span>
        </a>
      </div>
    </div>